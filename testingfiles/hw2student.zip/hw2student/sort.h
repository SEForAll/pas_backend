// ***
// *** DO NOT modify this file
// ***

#ifndef SORT_H
#define SORT_H
#include <stdio.h>
#include <stdbool.h>

void ssort(int * arr, int size);
bool checkOrder(int * arr, int size);
#endif
